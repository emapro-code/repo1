The Azure Naming Tool has been moved to a new GitHub repo in the Microsoft Patterns & Practices Organization. 
This change will allow us more frequent updates, enhanced features, and the ability to request new features and report bugs.

[**Go to the new Azure Naming Tool Repo**](https://github.com/mspnp/AzureNamingTool)

[View the Azure Naming Tool V3 Migration Guide](https://github.com/mspnp/AzureNamingTool/wiki/v3.0.0-Repository-Migration-Instructions)
